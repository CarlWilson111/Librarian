/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/*
 * Wrapper so that #include <gssapi.h> will work without special include
 * paths.
 */
#include <gssapi/gssapi.h>
